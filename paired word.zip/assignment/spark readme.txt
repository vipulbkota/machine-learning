Steps to run code-

used pyspark 

1)Stop current spark instances 
2)The code is writtern in jupyter so running the code in jupyter is more advisible 
3)libraries utlized are writtern in code 
4) output text part-000 is stored in output directory 

